/**
 */
package SAG.tests;

import SAG.SAGFactory;
import SAG.SAGmodel;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>SA Gmodel</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class SAGmodelTest extends TestCase {

	/**
	 * The fixture for this SA Gmodel test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SAGmodel fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(SAGmodelTest.class);
	}

	/**
	 * Constructs a new SA Gmodel test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SAGmodelTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this SA Gmodel test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(SAGmodel fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this SA Gmodel test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SAGmodel getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(SAGFactory.eINSTANCE.createSAGmodel());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //SAGmodelTest
